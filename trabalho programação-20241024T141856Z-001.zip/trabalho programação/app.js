function criaCartao(categoria, pergunta, resposta) {
    console.log(categoria, pergunta, resposta)
}